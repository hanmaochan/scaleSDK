//
//  AppDelegate.h
//  ChipseaCloudV3Demo
//
//  Created by iChipsea on 2023/1/13.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow * window;

@end

