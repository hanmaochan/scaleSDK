//
//  WeightProtocol_CsYunV3.h
//  CsBtUtil
//
//  Created by iChipsea on 2018/11/14.
//  Copyright © 2018 chipsea. All rights reserved.
//

#import "BaseProtocolWeight.h"


@interface WeightProtocol_CsYunV3 : BaseProtocolWeight

@property (nonatomic,retain) NSString * lastWeightTime; //上一次称重时间 锁定数据

@end

