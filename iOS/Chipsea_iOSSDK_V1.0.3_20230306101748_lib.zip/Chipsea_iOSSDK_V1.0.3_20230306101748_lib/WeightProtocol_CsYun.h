//
//  WeightProtocol_CsYun.h
//  CsBtUtil
//
//  Created by iChipsea on 2018/11/23.
//  Copyright © 2018 chipsea. All rights reserved.
//

#import "BaseProtocolWeight.h"


@interface WeightProtocol_CsYun : BaseProtocolWeight

@property (nonatomic,retain) NSString * lastWeightTime; //上一次称重时间 锁定数据

@end

