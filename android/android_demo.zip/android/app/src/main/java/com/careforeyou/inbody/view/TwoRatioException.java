package com.careforeyou.inbody.view;

/**
 * Created by Administrator on 2017/2/16.
 */

public class TwoRatioException extends RuntimeException {

    public TwoRatioException(String msg){
        super(msg);
    }
}
